﻿using System;
using System.Linq;
using NUnit.Framework;
using TddStore.Core;

namespace TddStore.UnitTests
{
    [TestFixture]
    class OrderServiceTests
    {
        [TestCase("12345", 1, 100, 12.75)]
        [TestCase("12399", 5, 200, 30)]
        [TestCase("54321", 4, 10, 1.5)]
        [TestCase("12332", 2, 1000, 142.5)]
        [TestCase("23251", 3, 555, 83.25)]
        public void ShouldBeAbleToComputeShipping(string zipCode, int customerLevel, decimal totalOrderAmount, decimal shippingCost)       
        {
            IShippingService shippingService = new ShippingService();

            var result = shippingService.ComputeShippingCost(zipCode, customerLevel, totalOrderAmount);

            Assert.AreEqual(shippingCost, result);
        }
    }
}
