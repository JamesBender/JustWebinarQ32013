using System;

namespace TddStore.Core
{
    public class ShoppingCartItem
    {
        public Guid ItemId;
        public int Quantity;
    }
}