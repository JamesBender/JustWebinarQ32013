using System;

namespace TddStore.Core.Exceptions
{
    public class InvalidOrderException : Exception
    {
        
    }
}