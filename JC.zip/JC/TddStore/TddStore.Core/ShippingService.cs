using System;
using System.Collections.Generic;
using System.Linq;

namespace TddStore.Core
{
    public interface IShippingService
    {
        decimal ComputeShippingCost(string zipCode, int customerLevel, decimal totalOrderAmount);
    }

    public class ShippingService : IShippingService
    {
        private IList<string> _discountZipCode;

        public ShippingService()
        {
            _discountZipCode = new List<string>(); 

            _discountZipCode.Add("12345");
            _discountZipCode.Add("12346");
            _discountZipCode.Add("12347");
            _discountZipCode.Add("12347");
            _discountZipCode.Add("12349");
            _discountZipCode.Add("12350");
            _discountZipCode.Add("12351");
        }

        public decimal ComputeShippingCost(string zipCode, int customerLevel, decimal totalOrderAmount)
        {
            var baseShipping = totalOrderAmount * .15M;
            var currentShipping = baseShipping;

            currentShipping = ComputeCustomerLoyaltyDiscount(customerLevel, baseShipping, currentShipping);

            currentShipping = CalculateZipCodeDiscount(zipCode, baseShipping, currentShipping);
            
            return currentShipping;
        }
  
        private decimal CalculateZipCodeDiscount(string zipCode, decimal baseShipping, decimal currentShipping)
        {
            if (_discountZipCode.Count(x => x == zipCode) > 0)
            {
                currentShipping = currentShipping - (baseShipping * .05M);
            }
            return currentShipping;
        }
  
        private decimal ComputeCustomerLoyaltyDiscount(int customerLevel, decimal baseShipping, decimal currentShipping)
        {
            var customerLevelDiscount = 0M;
            if (customerLevel == 1)
            {
                customerLevelDiscount = baseShipping * .1M;
            }

            if (customerLevel == 2)
            {
                customerLevelDiscount = baseShipping * .05M;
            }
            currentShipping = currentShipping - customerLevelDiscount;
            return currentShipping;
        }
            
    }
}