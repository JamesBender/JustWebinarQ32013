﻿Imports Telerik.JustMock
Imports NUnit.Framework

<TestFixture()>
Public Class MyUnitTests
    <Test()>
    Public Sub MyTest()
        Dim iBar = Mock.Create(Of IBar)()
    End Sub

End Class

Public Interface IBar
    Function Foo(ByVal x As Integer)
End Interface
