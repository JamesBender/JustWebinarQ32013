﻿using System;
using System.Linq;
using FluentNHibernate.Mapping;

namespace Awesome.Core
{
    public class Person
    {
        public virtual string FirstName { get; set; }
        public virtual string LastName { get; set; }
        public virtual int UserId { get; set; }
    }

    public class PersonMapping : ClassMap<Person>
    {
        public PersonMapping()
        {
            Table("People");
            Id(x => x.UserId).Unique();
            Map(x => x.FirstName);
            Map(x => x.LastName);
        }
    }
}
