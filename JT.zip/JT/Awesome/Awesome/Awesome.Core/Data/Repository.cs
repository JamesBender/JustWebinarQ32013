using System.Collections.Generic;
using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Tool.hbm2ddl;

namespace Awesome.Core.Data
{
    public class Repository
    {
        protected ISessionFactory SessionFactory { get; private set; }

        public Repository()
        {
            var connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["awesome"].ToString();
            SessionFactory = Fluently.Configure().Database(
                    MsSqlConfiguration.MsSql2008.ConnectionString(
                        c => c.Is(connectionString)))
                        //.ExposeConfiguration(BuildSchema)
                .Mappings(m => m.FluentMappings.AddFromAssemblyOf<Person>()).BuildSessionFactory();
        }

        private static void BuildSchema(Configuration config)
        {
            new SchemaExport(config).Create(false, true);
        }

        public int Create(Person person)
        {
            using(var session = SessionFactory.OpenSession())
            {
                var id = (int)session.Save(person);
                session.Flush();
                session.Evict(person);
                return id;
            }
        }

        public void Update(Person person)
        {
            using(var session = SessionFactory.OpenSession())
            {
                session.Merge(person);
                session.Flush();
                session.Evict(person);
            }
        }

        public Person Retrieve(int id)
        {
            using (var session = SessionFactory.OpenSession())
            {
                return session.Get<Person>(id);
            }
        }

        public IList<Person> Retrieve()
        {
            using (var session = SessionFactory.OpenSession())
            {
                return session.CreateCriteria<Person>().List<Person>();
            }
        }

        public void Delete(Person person)
        {
            using (var session = SessionFactory.OpenSession())
            {
                session.Delete(person);
                session.Flush();
                session.Evict(person);
            }
        }
    }
}