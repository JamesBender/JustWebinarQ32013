using NUnit.Framework;

namespace Awesome.Web.UnitTests.Controllers
{
    [TestFixture]
    public class WhenUsingThePersonController
    {
        
    }
}