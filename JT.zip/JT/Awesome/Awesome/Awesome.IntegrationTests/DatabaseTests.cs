using Awesome.Core;
using Awesome.Core.Data;
using NUnit.Framework;

namespace Awesome.IntegrationTests
{
    [TestFixture]
    public class DatabaseTests
    {
        [Test]
        public void ShouldBeAbleToConnectToDatabaseAndInsertAPerson()
        {
            var repo = new Repository();

            var person = new Person{FirstName = "Bob", LastName = "Smith"};
            var result = repo.Create(person);

            Assert.AreNotEqual(0, result);
        }
    }
}