using System;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using Awesome.Core;
using Awesome.Core.Data;
using Awesome.Web.Models.ViewModels;
using Person = Awesome.Web.Models.ViewModels.Person;

namespace Awesome.Web.Models
{
    public interface IPersonModel
    {
        IEnumerable<Person> GetAllPersonnel();
        Person GetPerson(int id);
        int SavePerson(Person person);
        int SavePerson(int id, Person person);
        void DeletePerson(int id);
    }

    public class PersonModel : IPersonModel
    {
        private readonly IPersonRepository _personRepository;
        private readonly Repository _repo; 

        public PersonModel(IPersonRepository personRepository)
        {
            _personRepository = personRepository;
            _repo = new Repository();
        }

        public IEnumerable<Person> GetAllPersonnel()
        {
            //return
            //    _personRepository.GetListOfPeople()
            //                     .Select(Mapper.Map<Core.Person, Person>)
            //                     .ToList();
            return _repo.Retrieve().Select(Mapper.Map<Core.Person, Person>).ToList<Person>();
        }

        public Person GetPerson(int id)
        {
            //var person = _personRepository.GetPerson(id);
            var person = _repo.Retrieve(id);

            return Mapper.Map<Core.Person, Person>(person);
        }

        public int SavePerson(Person person)
        {
            //return _personRepository.SavePerson(Mapper.Map<Person, Core.Person>(person));
            return _repo.Create(Mapper.Map<Person, Core.Person>(person));
        }

        public int SavePerson(int id, Person person)
        {
            //return _personRepository.SavePerson(id, Mapper.Map<Person, Core.Person>(person));
            _repo.Update(Mapper.Map<Person, Core.Person>(person));
            return id;
        }

        public void DeletePerson(int id)
        {
            //_personRepository.DeletePerson(id);
            var person = _repo.Retrieve(id);
            _repo.Delete(person);
        }
    }
}