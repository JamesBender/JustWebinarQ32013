﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeakingApp
{
	class Foo : IDisposable
	{
		public Foo()
		{
			Program.SomeEvent += Program_SomeEvent;
		}

		void Program_SomeEvent(object sender, EventArgs e)
		{
			Console.WriteLine("I'm here!");
		}

		public void Dispose()
		{
            Program.SomeEvent -= Program_SomeEvent;
        }
	}
	class Program
	{
		public static event EventHandler SomeEvent;
		public static void CreateObjects()
		{
			for (int i = 0; i < 3; i++)
			{
				var foo = new Foo();
				EventHandler handler = SomeEvent;

				if (handler != null)
				{
					handler(null, null);
				}

				foo.Dispose();
				
			}
		}
		static void Main(string[] args)
		{
			CreateObjects();
			Console.WriteLine("Waiting to read key!");
			Console.ReadKey();
		}
	}
}
